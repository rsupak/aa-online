# gamma_fn(n) = (n - 1)!

def gamma_fn(num)
  return if num <= 0
  return 1 if num == 1

  (num - 1) * gamma_fn(num - 1)
end

p gamma_fn(8)
