require_relative "room"

class Hotel
  
end
